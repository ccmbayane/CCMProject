import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-at',
	templateUrl: './at.component.html',
	styleUrls: ['./at.component.css']
})
export class AtComponent implements OnInit {
	constructor() { }

	ngOnInit(): void {
	}

}
